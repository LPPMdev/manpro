/**
 * Handle.spec.js
 * (c) 2015~ Summernote Team
 * summernote may be freely distributed under the MIT license./
 */
/* jshint unused: false */
define([
  'chai',
  'summernote/base/module/Handle'
], function (chai, Handle) {
  'use strict';

  var expect = chai.expect;

  describe('base:module.Handle', function () {
  });
});
